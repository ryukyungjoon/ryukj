class preprocessing:
    def __init__(self, num1=None, num2=None):
        self.num1 = num1
        self.num2 = num2

    def main(self):
        answer = self.num1 + self.num2
        return answer
