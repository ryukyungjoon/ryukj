from flask import Flask, render_template

import backend_calculate as bcal

app = Flask(__name__)


@app.route('/')
def home():
    return index()


@app.route('/index.html')  # URL 경로가 '/' = 127.0.0.1:5000
def index():
    return render_template('index.html')


@app.route('/about.html')  # URL 경로 설정
def about():
    return render_template('about.html')


@app.route('/contact.html')  # URL 경로 설정
def contact():
    return render_template('contact.html')


@app.route('/services.html')  # URL 경로 설정
def services():
    return render_template('services.html')


@app.route('/testimonials.html')
def testimonials():
    return render_template('testimonials.html')


@app.route('/preprocessing')
def preprocessing():
    answer = bcal.preprocessing(num1=1, num2=2).main()
    return render_template('result.html', answer=answer)


if __name__ == '__main__':
    app.run(debug=True)
